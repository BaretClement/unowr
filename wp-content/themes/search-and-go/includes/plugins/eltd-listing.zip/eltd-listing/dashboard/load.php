<?php
include_once 'dashboard-functions.php';
include_once 'page-templates/register-template.php';