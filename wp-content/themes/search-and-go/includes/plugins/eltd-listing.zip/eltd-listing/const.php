<?php

define('ELATED_LISTING_VERSION', '1.1.2');
define('ELATED_LISTING_ABS_PATH', dirname(__FILE__));
define('ELATED_LISTING_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('ELATED_LISTING_CPT_PATH', ELATED_LISTING_ABS_PATH.'/post-types');
define('ELATED_LISTING_MEMBERSHIP_PATH', ELATED_LISTING_ABS_PATH.'/dashboard');